import os
import uuid
from dataclasses import dataclass
from io import BytesIO

from fastapi import UploadFile
from PIL import Image, UnidentifiedImageError

from app.core.config import settings
from app.core.exceptions import FileUploadError

_EXTENSION_BY_CONTENT_TYPE = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}

_VIDEO_EXTENSION_BY_CONTENT_TYPE = {
    "video/mp4": ".mp4",
    "video/quicktime": ".mov",
}


@dataclass
class SavedImage:
    relative_path: str
    content_type: str
    size_bytes: int
    width: int
    height: int

    @property
    def url(self) -> str:
        return f"/uploads/{self.relative_path}"


@dataclass
class SavedVideo:
    relative_path: str
    content_type: str
    size_bytes: int

    @property
    def url(self) -> str:
        return f"/uploads/{self.relative_path}"


async def save_uploaded_video(file: UploadFile, subdirectory: str) -> SavedVideo:
    if file.content_type not in settings.ALLOWED_VIDEO_TYPES:
        raise FileUploadError(
            f"Unsupported video type '{file.content_type}'. Allowed types: "
            f"{', '.join(settings.ALLOWED_VIDEO_TYPES)}.",
            error_code="UNSUPPORTED_FILE_TYPE",
        )

    content = await file.read()

    if len(content) == 0:
        raise FileUploadError("Uploaded file is empty.", error_code="EMPTY_FILE")

    max_video_size = settings.MAX_UPLOAD_SIZE * 5
    if len(content) > max_video_size:
        max_mb = max_video_size / (1024 * 1024)
        raise FileUploadError(f"Video exceeds the {max_mb:.0f}MB size limit.", error_code="FILE_TOO_LARGE")

    extension = _VIDEO_EXTENSION_BY_CONTENT_TYPE[file.content_type]
    filename = f"{uuid.uuid4()}{extension}"

    destination_dir = os.path.join(settings.UPLOAD_DIRECTORY, subdirectory)
    os.makedirs(destination_dir, exist_ok=True)
    destination_path = os.path.join(destination_dir, filename)

    with open(destination_path, "wb") as f:
        f.write(content)

    return SavedVideo(
        relative_path=f"{subdirectory}/{filename}",
        content_type=file.content_type,
        size_bytes=len(content),
    )


async def save_uploaded_image(file: UploadFile, subdirectory: str) -> SavedImage:
    if file.content_type not in settings.ALLOWED_IMAGE_TYPES:
        raise FileUploadError(
            f"Unsupported image type '{file.content_type}'. Allowed types: "
            f"{', '.join(settings.ALLOWED_IMAGE_TYPES)}.",
            error_code="UNSUPPORTED_FILE_TYPE",
        )

    content = await file.read()

    if len(content) == 0:
        raise FileUploadError("Uploaded file is empty.", error_code="EMPTY_FILE")

    if len(content) > settings.MAX_UPLOAD_SIZE:
        max_mb = settings.MAX_UPLOAD_SIZE / (1024 * 1024)
        raise FileUploadError(f"File exceeds the {max_mb:.0f}MB size limit.", error_code="FILE_TOO_LARGE")

    try:
        probe = Image.open(BytesIO(content))
        probe.verify()
        image = Image.open(BytesIO(content))
        width, height = image.size
    except (UnidentifiedImageError, OSError):
        raise FileUploadError("Uploaded file is not a valid image.", error_code="INVALID_IMAGE")

    extension = _EXTENSION_BY_CONTENT_TYPE[file.content_type]
    filename = f"{uuid.uuid4()}{extension}"

    destination_dir = os.path.join(settings.UPLOAD_DIRECTORY, subdirectory)
    os.makedirs(destination_dir, exist_ok=True)
    destination_path = os.path.join(destination_dir, filename)

    with open(destination_path, "wb") as f:
        f.write(content)

    return SavedImage(
        relative_path=f"{subdirectory}/{filename}",
        content_type=file.content_type,
        size_bytes=len(content),
        width=width,
        height=height,
    )
