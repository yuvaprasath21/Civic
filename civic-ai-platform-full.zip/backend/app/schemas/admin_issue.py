from typing import List, Optional

from pydantic import BaseModel, Field

from app.schemas.issue import IssueSummaryResponse


class MergeIssuesRequest(BaseModel):
    duplicate_ids: List[str] = Field(min_length=1, max_length=50, description="UUIDs of issues to merge into the master")


class MergeResultResponse(BaseModel):
    success: bool = True
    message: str
    master_id: str
    master_reference_code: str
    report_count: int  # master + all merged/linked duplicates
    priority_score: float
    priority_level: str


class DuplicateListResponse(BaseModel):
    master_reference_code: str
    report_count: int
    duplicates: List[IssueSummaryResponse]
